#include<bits/stdc++.h>
using namespace std;
int main(){
    long long n;
    scanf("%lld",&n);
    printf("%lld",n*(n-1)+2); 
    return 0;
}